package ru.dmitrybigshon.vsiluet;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.splashscreen.SplashScreen;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private SwipeRefreshLayout swipe;
    private JSONObject cfg = new JSONObject();
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest webPerm;
    private String geoOrigin;
    private GeolocationPermissions.Callback geoCb;
    private static final int RC_FILE = 101, RC_PERM = 102;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle s) {
        SplashScreen.installSplashScreen(this);
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        try {
            InputStream in = getAssets().open("config.json");
            byte[] b = new byte[in.available()]; in.read(b); in.close();
            cfg = new JSONObject(new String(b, StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
        String url = cfg.optString("url", "https://example.com");
        getWindow().setStatusBarColor(parse(cfg.optString("statusBar", "#0B1020")));
        getWindow().setNavigationBarColor(parse(cfg.optString("statusBar", "#0B1020")));
        if (cfg.optBoolean("fullscreen", false)) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        swipe = findViewById(R.id.swipe);
        web = findViewById(R.id.web);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        st.setUseWideViewPort(true);
        st.setLoadWithOverviewMode(true);
        st.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        st.setCacheMode(WebSettings.LOAD_DEFAULT);
        boolean zoom = cfg.optBoolean("zoom", false);
        st.setSupportZoom(zoom);
        st.setBuiltInZoomControls(zoom);
        st.setDisplayZoomControls(false);
        String ua = cfg.optString("ua", "");
        if (ua.equals("desktop")) st.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36");
        else if (!ua.isEmpty() && !ua.equals("default")) st.setUserAgentString(ua);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        swipe.setOnRefreshListener(new Runnable(){ public void run(){ web.reload(); }});
        swipe.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback(){
            public boolean canChildScrollUp(SwipeRefreshLayout p, View c){ return web.getScrollY() > 0; }
        });
        if (!cfg.optBoolean("pull", true)) swipe.setEnabled(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http") || scheme.equals("https")) {
                    if (allowed(u)) return false;
                    if (cfg.optBoolean("extBrowser", true)) { open(u); return true; }
                    return false;
                }
                open(u); return true;
            }
            @Override public void onPageFinished(WebView v, String u) { swipe.setRefreshing(false); }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame() && cfg.optBoolean("offline", true)) {
                    v.loadDataWithBaseURL(cfg.optString("url", ""), offlineHtml(), "text/html", "utf-8", null);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest r) {
                if (!cfg.optBoolean("camera", false)) { r.deny(); return; }
                List<String> need = new ArrayList<>();
                for (String res : r.getResources()) {
                    if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                    if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                }
                webPerm = r;
                if (need.isEmpty()) r.grant(r.getResources());
                else ActivityCompat.requestPermissions(MainActivity.this, need.toArray(new String[0]), RC_PERM);
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (!cfg.optBoolean("geo", false)) { cb.invoke(origin, false, false); return; }
                geoOrigin = origin; geoCb = cb;
                if (has(Manifest.permission.ACCESS_FINE_LOCATION)) cb.invoke(origin, true, false);
                else ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, RC_PERM);
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (!cfg.optBoolean("files", true)) return false;
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), RC_FILE); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        if (cfg.optBoolean("files", true)) {
            web.setDownloadListener(new android.webkit.DownloadListener() {
                public void onDownloadStart(String u, String ua2, String cd, String mime, long len) {
                    try {
                        DownloadManager.Request q = new DownloadManager.Request(Uri.parse(u));
                        q.setMimeType(mime);
                        String ck = CookieManager.getInstance().getCookie(u);
                        if (ck != null) q.addRequestHeader("Cookie", ck);
                        q.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        String fn = URLUtil.guessFileName(u, cd, mime);
                        q.setTitle(fn);
                        q.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                        ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(q);
                        Toast.makeText(MainActivity.this, "Скачивание началось", Toast.LENGTH_SHORT).show();
                    } catch (Exception ex) { open(Uri.parse(u)); }
                }
            });
        }
        if (s != null) web.restoreState(s); else web.loadUrl(url);
    }
    private boolean allowed(Uri u) {
        String host = u.getHost() == null ? "" : u.getHost();
        try {
            String base = Uri.parse(cfg.optString("url", "")).getHost();
            if (base != null && (host.equals(base) || host.endsWith("." + base))) return true;
            JSONArray arr = cfg.optJSONArray("hosts");
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                String h = arr.getString(i).trim();
                if (!h.isEmpty() && (host.equals(h) || host.endsWith("." + h))) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }
    private void open(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
        catch (Exception e) { Toast.makeText(this, "Нет приложения для ссылки", Toast.LENGTH_SHORT).show(); }
    }
    private boolean has(String p) { return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED; }
    private int parse(String c) { try { return Color.parseColor(c); } catch (Exception e) { return Color.parseColor("#0B1020"); } }
    private String offlineHtml() {
        try {
            InputStream in = getAssets().open("offline.html");
            byte[] b = new byte[in.available()]; in.read(b); in.close();
            return new String(b, StandardCharsets.UTF_8).replace("%URL%", cfg.optString("url", ""));
        } catch (Exception e) { return "<h3>Нет сети</h3><a href='%URL%'>Повторить</a>"; }
    }
    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        super.onRequestPermissionsResult(rc, p, g);
        boolean ok = g.length > 0;
        for (int x : g) if (x != PackageManager.PERMISSION_GRANTED) ok = false;
        if (webPerm != null) { if (ok) webPerm.grant(webPerm.getResources()); else webPerm.deny(); webPerm = null; }
        if (geoCb != null) { geoCb.invoke(geoOrigin, ok, false); geoCb = null; }
    }
    @Override protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (rc == RC_FILE && fileCb != null) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount(); out = new Uri[n];
                    for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            fileCb.onReceiveValue(out); fileCb = null;
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); if (web != null) web.saveState(b); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}

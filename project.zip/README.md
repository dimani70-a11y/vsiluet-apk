# V-Силуэт

WebView-оболочка, сгенерирована WEB→APK конвертером.
Сайт: https://dmitrybigshon.neocities.org

Сборка: GitHub Actions (build.yml из комплекта) или Android Studio.
Настройки оболочки: app/src/main/assets/config.json
